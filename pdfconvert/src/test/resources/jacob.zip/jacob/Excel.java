package net.netca.pdfconvert.api.jacob;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import net.netca.pdfconvert.constant.PDFConstant;
import net.netca.pdfconvert.dto.ConvertDto;
import net.netca.pdfconvert.dto.FileDataDto;
import net.netca.pdfconvert.exception.PDFConvertException;

/**
 * 功能： 将Office文件转换为PDF文档
 * 
 * 依赖外部jar包：jacob.jar(包括jacob-1.18-x64.dll，此文件要放在C:\Windows\System32\下)
 * com.lowagie.text-2.1.7.jar, 相关包见resource文件夹
 * 
 * @author liyuhao
 *
 */
public class Excel {
	private static Log log = LogFactory.getLog(Excel.class);
	private ConvertDto convertDto;

	public Excel(FileDataDto fileDataDto) {
		if (fileDataDto == null) {
			throw new PDFConvertException("传入数据为空！");
		}

		if (StringUtils.isEmpty(fileDataDto.getSourceExtension())) {
			throw new PDFConvertException("源文件扩展名为空！");
		}
		if (StringUtils.isEmpty(fileDataDto.getTargetExtension())) {
			throw new PDFConvertException("目的文件扩展名为空！");
		}

		String tempSourceExtension = "." + fileDataDto.getSourceExtension().replaceAll("\\.", "");
		if (!PDFConstant.jacobExcel.contains(tempSourceExtension.toLowerCase())) {
			throw new PDFConvertException("源文件扩展名非法！");
		}

		String tempTargetExtension = "." + fileDataDto.getTargetExtension().replaceAll("\\.", "");
		if (!PDFConstant.pdf.contains(tempTargetExtension.toLowerCase())) {
			throw new PDFConvertException("目的文件扩展名非法！");
		}

		convertDto = PDFConstant.formatConvertDto(fileDataDto, tempSourceExtension, tempTargetExtension);
	}

	/**
	 * excel文件转pdf，具有数据源分析的打开失败
	 * 
	 * @param source
	 *            待转换的文件绝对路径
	 * @param target
	 *            保存为pdf文件的绝对路径
	 */
	public boolean convertToPDF() {

		long start = System.currentTimeMillis();
		ActiveXComponent app = new ActiveXComponent("Excel.Application");
		try {
			app.setProperty("Visible", false);
			Dispatch workbooks = app.getProperty("Workbooks").toDispatch();
			log.info("打开文档:" + convertDto.source);
			Dispatch workbook = Dispatch
					.invoke(workbooks, "Open", Dispatch.Method,
							new Object[] { convertDto.source, new Variant(false), new Variant(false) }, new int[3])
					.toDispatch();
			Dispatch.invoke(workbook, "SaveAs", Dispatch.Method,
					new Object[] { convertDto.target, new Variant(57), new Variant(false), new Variant(57),
							new Variant(57), new Variant(false), new Variant(true), new Variant(57), new Variant(true),
							new Variant(true), new Variant(true) },
					new int[1]);
			Variant f = new Variant(false);
			log.info("转换文档到PDF:" + convertDto.target);
			Dispatch.call(workbook, "Close", f);
			long end = System.currentTimeMillis();
			log.info("转换完成,用时：" + (end - start) + "ms.");
			convertDto.timeUse = (end - start) + "ms";
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new PDFConvertException("文件转换失败！" + e.getMessage());
		} finally {
			if (app != null) {
				app.invoke("Quit", new Variant[] {});
			}
		}
	}

	public ConvertDto getConvertDto() {
		return convertDto;
	}

	public void setConvertDto(ConvertDto convertDto) {
		this.convertDto = convertDto;
	}

}