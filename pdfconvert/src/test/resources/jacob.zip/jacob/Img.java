package net.netca.pdfconvert.api.jacob;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.lowagie.text.Document;
import com.lowagie.text.Image;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfWriter;

import net.netca.pdfconvert.constant.PDFConstant;
import net.netca.pdfconvert.dto.ConvertDto;
import net.netca.pdfconvert.dto.FileDataDto;
import net.netca.pdfconvert.exception.PDFConvertException;

/**
 * 功能： 将Office文件转换为PDF文档
 * 
 * 依赖外部jar包：jacob.jar(包括jacob-1.18-x64.dll，此文件要放在C:\Windows\System32\下)
 * com.lowagie.text-2.1.7.jar, 相关包见resource文件夹
 * 
 * @author liyuhao
 *
 */
public class Img {
	private static Log log = LogFactory.getLog(Img.class);
	private ConvertDto convertDto;

	public Img(FileDataDto fileDataDto) {
		if (fileDataDto == null) {
			throw new PDFConvertException("传入数据为空！");
		}

		if (StringUtils.isEmpty(fileDataDto.getSourceExtension())) {
			throw new PDFConvertException("源文件扩展名为空！");
		}
		if (StringUtils.isEmpty(fileDataDto.getTargetExtension())) {
			throw new PDFConvertException("目的文件扩展名为空！");
		}

		String tempSourceExtension = "." + fileDataDto.getSourceExtension().replaceAll("\\.", "");
		if (!PDFConstant.jacobImg.contains(tempSourceExtension.toLowerCase())) {
			throw new PDFConvertException("源文件扩展名非法！");
		}

		String tempTargetExtension = "." + fileDataDto.getTargetExtension().replaceAll("\\.", "");
		if (!PDFConstant.pdf.contains(tempTargetExtension.toLowerCase())) {
			throw new PDFConvertException("目的文件扩展名非法！");
		}

		convertDto = PDFConstant.formatConvertDto(fileDataDto, tempSourceExtension, tempTargetExtension);
	}

	/**
	 * 将图片文件转pdf
	 * 
	 * @param source
	 *            待转换的文件绝对路径
	 * @param target
	 *            保存为pdf文件的绝对路径
	 * @throws IOException
	 */
	public boolean convertToPDF() throws IOException {

		long start = System.currentTimeMillis();
		Document document = new Document();
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(convertDto.target);
			PdfWriter.getInstance(document, fos);

			// 添加PDF文档的某些信息，比如作者，主题等等
			document.addAuthor("root");
			document.addSubject("file to pdf.");
			// 设置文档的大小
			document.setPageSize(PageSize.A4);
			// 打开文档
			document.open();
			// 写入一段文字
			// document.add(new Paragraph("JUST TEST ..."));
			// 读取一个图片
			Image image = Image.getInstance(convertDto.source);
			log.info("打开文档:" + convertDto.source);
			log.info("转换文档到PDF:" + convertDto.target);
			float imageHeight = image.getScaledHeight();
			float imageWidth = image.getScaledWidth();
			int i = 0;
			while (imageHeight > 500 || imageWidth > 500) {
				image.scalePercent(100 - i);
				i++;
				imageHeight = image.getScaledHeight();
				imageWidth = image.getScaledWidth();
				log.info("imageHeight->" + imageHeight);
				log.info("imageWidth->" + imageWidth);
			}

			image.setAlignment(Image.ALIGN_CENTER);
			// //设置图片的绝对位置
			// image.setAbsolutePosition(0, 0);
			// image.scaleAbsolute(500, 400);
			// 插入一个图片
			document.add(image);

			long end = System.currentTimeMillis();
			log.info("转换完成,用时：" + (end - start) + "ms.");
			convertDto.timeUse = (end - start) + "ms";
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new PDFConvertException("文件转换失败！" + e.getMessage());
		} finally {
			if (document != null) {
				document.close();
			}
			if (fos != null) {
				fos.flush();
				fos.close();
			}
		}
	}

	public ConvertDto getConvertDto() {
		return convertDto;
	}

	public void setConvertDto(ConvertDto convertDto) {
		this.convertDto = convertDto;
	}
}