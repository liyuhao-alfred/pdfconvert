package net.netca.pdfconvert.api.jacob;

import java.io.File;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.Dispatch;

import net.netca.pdfconvert.constant.PDFConstant;
import net.netca.pdfconvert.dto.ConvertDto;
import net.netca.pdfconvert.dto.FileDataDto;
import net.netca.pdfconvert.exception.PDFConvertException;

/**
 * 功能： 将Office文件转换为PDF文档
 * 
 * 依赖外部jar包：jacob.jar(包括jacob-1.18-x64.dll，此文件要放在C:\Windows\System32\下)
 * com.lowagie.text-2.1.7.jar, 相关包见resource文件夹
 * 
 * @author liyuhao
 *
 */
public class Word {
	private static Log log = LogFactory.getLog(Word.class);
	private ConvertDto convertDto;

	public Word(FileDataDto fileDataDto) {
		if (fileDataDto == null) {
			throw new PDFConvertException("传入数据为空！");
		}

		if (StringUtils.isEmpty(fileDataDto.getSourceExtension())) {
			throw new PDFConvertException("源文件扩展名为空！");
		}
		if (StringUtils.isEmpty(fileDataDto.getTargetExtension())) {
			throw new PDFConvertException("目的文件扩展名为空！");
		}

		String tempSourceExtension = "." + fileDataDto.getSourceExtension().replaceAll("\\.", "");
		if (!PDFConstant.jacobDoc.contains(tempSourceExtension.toLowerCase())) {
			throw new PDFConvertException("源文件扩展名非法！");
		}

		String tempTargetExtension = "." + fileDataDto.getTargetExtension().replaceAll("\\.", "");
		if (!PDFConstant.pdf.contains(tempTargetExtension.toLowerCase())) {
			throw new PDFConvertException("目的文件扩展名非法！");
		}

		convertDto = PDFConstant.formatConvertDto(fileDataDto, tempSourceExtension, tempTargetExtension);
	}

	/**
	 * 将.doc或者.docx文件转换成pdf文件
	 * 
	 * @param source
	 *            待转换的文件绝对路径
	 * @param target
	 *            保存为pdf文件的绝对路径
	 */
	public boolean convertToPDF() {
		long start = System.currentTimeMillis();
		ActiveXComponent app = null;
		Dispatch docs = null;
		try {
			app = new ActiveXComponent("Word.Application");
			app.setProperty("Visible", false);

			docs = app.getProperty("Documents").toDispatch();
			log.info("打开文档:" + convertDto.source);
			Dispatch doc = Dispatch.call(docs, "Open", convertDto.source, false, true).toDispatch();

			log.info("转换文档到PDF:" + convertDto.target);
			File tofile = new File(convertDto.target);
			if (tofile.exists()) {
				tofile.delete();
			}
			Dispatch.call(doc, "SaveAs", convertDto.target, PDFConstant.wdFormatPDF);
			Dispatch.call(doc, "Close", false);
			long end = System.currentTimeMillis();
			log.info("转换完成,用时：" + (end - start) + "ms.");
			convertDto.timeUse = (end - start) + "ms";
			return true;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new PDFConvertException("文件转换失败！" + e.getMessage());
		} finally {
			if (docs != null) {
				if (app != null)
					app.invoke("Quit", PDFConstant.wdDoNotSaveChanges);
			}

		}

	}

	public ConvertDto getConvertDto() {
		return convertDto;
	}

	public void setConvertDto(ConvertDto convertDto) {
		this.convertDto = convertDto;
	}
}